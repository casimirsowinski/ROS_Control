-- 3dvia.com   --

The zip file 00dzs.dae.zip contains the following files :
- readme.txt
- models/00dzs.dae


-- Model information --

Model Name : TABLE CONTOUR
Author : Ligne_Roset
Publisher : Ligne_Roset

You can view this model here :
http://www.3dvia.com/content/78984D6E40526476
More models about this author :
http://www.3dvia.com/Ligne_Roset


-- Attached license --

A license is attached to the TABLE CONTOUR model and all related media.
You must agree with this licence before using the enclosed media.

License : Attribution License 2.5
Detailed license : http://creativecommons.org/licenses/by/2.5/

The licenses used by 3dvia are based on Creative Commons Licenses.
More info: http://creativecommons.org/about/licenses/meet-the-licenses
